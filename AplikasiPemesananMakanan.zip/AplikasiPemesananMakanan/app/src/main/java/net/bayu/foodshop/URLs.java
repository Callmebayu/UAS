package net.bayu.foodshop;

public class URLs {

    private static final String ROOT_URL = "http://192.168.43.207/android/Api.php?apicall=";
    public static final String URL_REGISTER = ROOT_URL + "signup";
    public static final String URL_LOGIN = ROOT_URL + "login";
}