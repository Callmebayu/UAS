package net.bayu.foodshop;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class ShoppingActivity extends AppCompatActivity {

    private WebViewClient MyWebViewClient;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping);
        WebView myWebView = (WebView) findViewById(R.id.webview1);
        myWebView.setWebViewClient(MyWebViewClient);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        WebView.enableSlowWholeDocumentDraw();
        myWebView.loadUrl("http://192.168.43.207/toko/toko.php");
    }
}